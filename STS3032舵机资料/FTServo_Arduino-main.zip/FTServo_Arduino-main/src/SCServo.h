/*
 * SCServo.h
 * 飞特串行舵机接口
 * 日期: 2024.11.24
 * 作者: txl
 */

#ifndef _SCSERVO_H
#define _SCSERVO_H

#include "SCSCL.h"
#include "SMS_STS.h"
#include "HLSCL.h"

#endif